from telegram.ext import Application

from . import ai, antispam, info, moderation, notes, rules, start, welcome


def register_all(application: Application) -> None:
    """Register every handler module on the application."""
    start.register(application)
    welcome.register(application)
    moderation.register(application)
    rules.register(application)
    notes.register(application)
    info.register(application)
    ai.register(application)
    # antispam is registered last so its message handler runs after others on group 0,
    # but it lives on its own group so all message handlers see every update.
    antispam.register(application)
