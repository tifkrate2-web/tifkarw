"""Telegram group assistant bot."""

__version__ = "0.1.0"
